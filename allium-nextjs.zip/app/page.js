'use client'

import { useState, useEffect, useCallback } from "react";

// Mock storage API for browsers that don't have it
if (typeof window !== 'undefined' && typeof window.storage === 'undefined') {
  window.storage = {
    async get(key, shared) {
      const val = localStorage.getItem(key);
      return val ? { key, value: val, shared } : null;
    },
    async set(key, value, shared) {
      localStorage.setItem(key, value);
      return { key, value, shared };
    },
    async delete(key, shared) {
      localStorage.removeItem(key);
      return { key, deleted: true, shared };
    },
    async list(prefix, shared) {
      return { keys: [], prefix, shared };
    }
  };
}

export default function Home() {
  return <AlliumIntelApp />
}


// ===================================================
// ALLIUM WALLET INTELLIGENCE + MARKET DASHBOARD
// Real-time wallet lookup + cross-chain market data
// ===================================================

// --- Pre-loaded market data from Allium (queried Feb 5, 2026) ---
const PRICE_DATA = {
  ethereum: { price: 1920.05, change24h: -10.63, vol24h: 1837.5, twoWeekChange: -22.4 },
  solana: { price: 82.70, change24h: -10.49, vol24h: 12245.2, twoWeekChange: -28.7 },
  bitcoin: { price: 95250.00, change24h: -8.92, vol24h: 3420.8, twoWeekChange: -18.3 },
};

const STABLECOIN_DATA = {
  ethereum: { usdc: 448.2, usdt: 184.6, dai: 25.8, total: 658.6 },
  solana: { usdc: 234.0, usdt: 16.9, dai: 0.0003, total: 250.9 },
};

// --- HISTORICAL CYCLE DRAWDOWNS (major dips in each 4-year cycle) ---
const CYCLE_DRAWDOWNS = {
  bitcoin: [
    { cycle: "2013-2017", event: "Mt. Gox Hack", date: "Feb 2014", peak: 1150, bottom: 175, drawdown: -84.8, duration: "2 weeks", recovery: "14 months" },
    { cycle: "2013-2017", event: "China Exchange Ban", date: "Sep 2017", peak: 4980, bottom: 2972, drawdown: -40.3, duration: "2 weeks", recovery: "2 months" },
    { cycle: "2017-2021", event: "COVID Crash", date: "Mar 2020", peak: 10500, bottom: 3850, drawdown: -63.3, duration: "1 week", recovery: "5 months" },
    { cycle: "2021-2025", event: "FTX Collapse", date: "Nov 2022", peak: 21000, bottom: 15500, drawdown: -26.2, duration: "1 week", recovery: "18 months" },
    { cycle: "2021-2025", event: "Silicon Valley Bank", date: "Mar 2023", peak: 28400, bottom: 19800, drawdown: -30.3, duration: "3 days", recovery: "2 months" },
    { cycle: "2025-2029", event: "Feb 2026 Dip", date: "Feb 2026", peak: 116500, bottom: 95250, drawdown: -18.3, duration: "2 weeks", recovery: "?" },
  ],
  ethereum: [
    { cycle: "2015-2019", event: "DAO Hack", date: "Jun 2016", peak: 21.50, bottom: 6.00, drawdown: -72.1, duration: "2 weeks", recovery: "8 months" },
    { cycle: "2017-2021", event: "COVID Crash", date: "Mar 2020", peak: 290, bottom: 85, drawdown: -70.7, duration: "1 week", recovery: "6 months" },
    { cycle: "2017-2021", event: "China Mining Ban", date: "May 2021", peak: 4380, bottom: 1700, drawdown: -61.2, duration: "3 weeks", recovery: "4 months" },
    { cycle: "2021-2025", event: "FTX Collapse", date: "Nov 2022", peak: 1650, bottom: 880, drawdown: -46.7, duration: "1 week", recovery: "20 months" },
    { cycle: "2021-2025", event: "USDC Depeg", date: "Mar 2023", peak: 1850, bottom: 1365, drawdown: -26.2, duration: "2 days", recovery: "3 weeks" },
    { cycle: "2025-2029", event: "Feb 2026 Dip", date: "Feb 2026", peak: 2475, bottom: 1920, drawdown: -22.4, duration: "2 weeks", recovery: "?" },
  ],
  solana: [
    { cycle: "2020-2024", event: "FTX Collapse", date: "Nov 2022", peak: 260, bottom: 8, drawdown: -96.9, duration: "2 weeks", recovery: "24+ months" },
    { cycle: "2020-2024", event: "Network Outage", date: "Feb 2023", peak: 27, bottom: 18, drawdown: -33.3, duration: "1 day", recovery: "2 months" },
    { cycle: "2020-2024", event: "Meme Coin Crash", date: "Apr 2024", peak: 205, bottom: 128, drawdown: -37.6, duration: "1 week", recovery: "6 weeks" },
    { cycle: "2025-2029", event: "Feb 2026 Dip", date: "Feb 2026", peak: 116, bottom: 82.7, drawdown: -28.7, duration: "2 weeks", recovery: "?" },
  ],
};

// --- EXAMPLE WALLETS for the team to try ---
const EXAMPLE_WALLETS = [
  { label: "Vitalik Buterin", address: "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045", chain: "ethereum" },
  { label: "Justin Sun", address: "0x176F3DAb24a159341c0509bB36B833E7fdd0a132", chain: "ethereum" },
  { label: "Coinbase", address: "0x503828976D22510aad0201ac7EC88293211D23Da", chain: "ethereum" },
];

// --- Utility ---
function shortenAddr(a) { return a ? a.slice(0, 6) + "…" + a.slice(-4) : ""; }
function timeAgo(ts) {
  const diff = (Date.now() - new Date(ts).getTime()) / 1000;
  if (diff < 60) return `${Math.floor(diff)}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

// === COMPONENTS ===

function LiveDot({ label }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
      <style>{`@keyframes pulse{0%,100%{opacity:1;box-shadow:0 0 0 0 rgba(0,227,158,0.4)}50%{opacity:0.5;box-shadow:0 0 0 6px rgba(0,227,158,0)}}`}</style>
      <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#00E39E", animation: "pulse 2s infinite" }} />
      <span style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: 2 }}>{label || "Live · Allium"}</span>
    </div>
  );
}

function TabButton({ label, active, onClick, color }) {
  return (
    <button onClick={onClick} style={{
      background: active ? "rgba(255,255,255,0.08)" : "transparent",
      border: active ? `1px solid ${color || "#00E39E"}40` : "1px solid rgba(255,255,255,0.06)",
      borderRadius: 8, padding: "10px 20px", cursor: "pointer", transition: "all 0.2s ease",
      color: active ? "#fff" : "rgba(255,255,255,0.4)", fontSize: 13, fontWeight: 500,
    }}>
      {label}
    </button>
  );
}

function Spinner() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, padding: 40, justifyContent: "center" }}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <div style={{ width: 20, height: 20, border: "2px solid rgba(255,255,255,0.1)", borderTopColor: "#00E39E", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
      <span style={{ fontSize: 13, color: "rgba(255,255,255,0.4)" }}>Querying Allium...</span>
    </div>
  );
}

// --- Transaction row ---
function TxRow({ tx, index }) {
  const transfer = tx.asset_transfers?.[0];
  const isReceived = transfer?.transfer_type === "received";
  const symbol = transfer?.asset?.symbol || "???";
  const amount = transfer?.amount?.amount_str || "0";
  const name = transfer?.asset?.name || symbol;

  // Truncate display amount
  let displayAmount = amount;
  if (amount.length > 12) displayAmount = parseFloat(amount).toLocaleString(undefined, { maximumFractionDigits: 6 });

  return (
    <div style={{
      display: "grid", gridTemplateColumns: "80px 1fr 140px 100px", gap: 12, alignItems: "center",
      padding: "12px 16px", background: index % 2 === 0 ? "rgba(255,255,255,0.02)" : "transparent",
      borderRadius: 6, transition: "background 0.15s ease",
    }}
    onMouseEnter={(e) => e.currentTarget.style.background = "rgba(255,255,255,0.05)"}
    onMouseLeave={(e) => e.currentTarget.style.background = index % 2 === 0 ? "rgba(255,255,255,0.02)" : "transparent"}
    >
      <span style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", fontFamily: "'JetBrains Mono', monospace" }}>
        {timeAgo(tx.block_timestamp)}
      </span>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <div style={{
          width: 24, height: 24, borderRadius: 6,
          background: isReceived ? "rgba(0,227,158,0.15)" : "rgba(255,77,106,0.15)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 12, color: isReceived ? "#00E39E" : "#FF4D6A",
        }}>
          {isReceived ? "↓" : "↑"}
        </div>
        <div>
          <div style={{ fontSize: 12, color: "#fff", fontWeight: 500 }}>{name}</div>
          <div style={{ fontSize: 10, color: "rgba(255,255,255,0.25)" }}>
            {isReceived ? "from " : "to "}{shortenAddr(isReceived ? tx.from_address : tx.to_address)}
          </div>
        </div>
      </div>
      <div style={{ textAlign: "right" }}>
        <span style={{
          fontSize: 13, fontWeight: 600, fontFamily: "'JetBrains Mono', monospace",
          color: isReceived ? "#00E39E" : "#FF4D6A",
        }}>
          {isReceived ? "+" : "-"}{displayAmount}
        </span>
        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)" }}>{symbol}</div>
      </div>
      <a
        href={`https://etherscan.io/tx/${tx.hash}`}
        target="_blank"
        rel="noopener noreferrer"
        style={{ fontSize: 10, color: "rgba(255,255,255,0.2)", fontFamily: "'JetBrains Mono', monospace", textDecoration: "none", textAlign: "right" }}
      >
        {shortenAddr(tx.hash)}
      </a>
    </div>
  );
}

// --- Market Overview Mini Cards ---
function MarketMini() {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
      {[
        { name: "ETH", ...PRICE_DATA.ethereum, stable: STABLECOIN_DATA.ethereum, color: "#627EEA" },
        { name: "SOL", ...PRICE_DATA.solana, stable: STABLECOIN_DATA.solana, color: "#00FFA3" },
      ].map((c) => (
        <div key={c.name} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: 20 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
            <div style={{ width: 28, height: 28, borderRadius: "50%", background: `${c.color}20`, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ fontSize: 11, fontWeight: 700, color: c.color }}>{c.name}</span>
            </div>
            <span style={{ fontSize: 18, fontWeight: 700, color: "#fff", fontFamily: "'JetBrains Mono', monospace" }}>
              ${c.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
            <span style={{ fontSize: 11, color: c.change24h >= 0 ? "#00E39E" : "#FF4D6A", marginLeft: "auto" }}>
              {c.change24h >= 0 ? "+" : ""}{c.change24h.toFixed(1)}%
            </span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            <div>
              <div style={{ fontSize: 9, color: "rgba(255,255,255,0.25)", textTransform: "uppercase", letterSpacing: 1 }}>24h Volume</div>
              <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", fontFamily: "'JetBrains Mono', monospace" }}>
                ${c.vol24h >= 1000 ? (c.vol24h / 1000).toFixed(1) + "T" : c.vol24h.toFixed(0) + "B"}
              </div>
            </div>
            <div>
              <div style={{ fontSize: 9, color: "rgba(255,255,255,0.25)", textTransform: "uppercase", letterSpacing: 1 }}>7d Stables</div>
              <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", fontFamily: "'JetBrains Mono', monospace" }}>
                ${c.stable.total.toFixed(0)}B
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// --- MARKET FREAKOUT COMPARISON ---
function MarketFreakout() {
  const [selectedAsset, setSelectedAsset] = useState("bitcoin");
  
  const assets = [
    { id: "bitcoin", name: "BTC", color: "#F7931A", current: PRICE_DATA.bitcoin.twoWeekChange },
    { id: "ethereum", name: "ETH", color: "#627EEA", current: PRICE_DATA.ethereum.twoWeekChange },
    { id: "solana", name: "SOL", color: "#00FFA3", current: PRICE_DATA.solana.twoWeekChange },
  ];

  const drawdowns = CYCLE_DRAWDOWNS[selectedAsset];
  const currentAsset = assets.find(a => a.id === selectedAsset);

  // Find current dip in the drawdowns (last item with "?")
  const currentDip = drawdowns.find(d => d.recovery === "?");

  return (
    <div>
      {/* Asset selector */}
      <div style={{ display: "flex", gap: 8, marginBottom: 24 }}>
        {assets.map((a) => (
          <button key={a.id} onClick={() => setSelectedAsset(a.id)} style={{
            flex: 1, padding: "14px 20px", borderRadius: 10, cursor: "pointer", transition: "all 0.2s ease",
            background: selectedAsset === a.id ? `${a.color}15` : "rgba(255,255,255,0.02)",
            border: selectedAsset === a.id ? `2px solid ${a.color}40` : "1px solid rgba(255,255,255,0.06)",
            color: "#fff",
          }}>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginBottom: 4 }}>{a.name}</div>
            <div style={{ fontSize: 20, fontWeight: 700, fontFamily: "'JetBrains Mono', monospace", color: a.color }}>
              {a.current.toFixed(1)}%
            </div>
            <div style={{ fontSize: 9, color: "rgba(255,255,255,0.3)", marginTop: 4 }}>2-Week Change</div>
          </button>
        ))}
      </div>

      {/* Current dip callout */}
      <div style={{
        background: "rgba(255,77,106,0.08)", border: "1px solid rgba(255,77,106,0.2)",
        borderRadius: 12, padding: 20, marginBottom: 24,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
          <div style={{ fontSize: 32 }}>📉</div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: "#fff" }}>
              Current {currentAsset.name} Dip: {currentDip.drawdown.toFixed(1)}%
            </div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>
              {currentDip.duration} drawdown · Started at ${currentDip.peak.toLocaleString()}
            </div>
          </div>
        </div>
        <div style={{ fontSize: 12, color: "rgba(255,255,255,0.6)", lineHeight: 1.6 }}>
          How does this compare to past cycles? Scroll down to see historical drawdowns...
        </div>
      </div>

      {/* Drawdown Comparison Chart */}
      <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: 20, marginBottom: 24 }}>
        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", textTransform: "uppercase", letterSpacing: 2, marginBottom: 20 }}>
          📊 Drawdown Severity Comparison
        </div>

        <div style={{ position: "relative", height: 320, paddingLeft: 50, paddingBottom: 40 }}>
          {/* Y-axis labels */}
          <div style={{ position: "absolute", left: 0, top: 0, bottom: 40, width: 40, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
            {[0, -25, -50, -75, -100].map((val) => (
              <div key={val} style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", textAlign: "right", fontFamily: "'JetBrains Mono', monospace" }}>
                {val}%
              </div>
            ))}
          </div>

          {/* Grid lines */}
          <div style={{ position: "absolute", left: 50, right: 0, top: 0, bottom: 40 }}>
            {[0, 25, 50, 75, 100].map((pct) => (
              <div key={pct} style={{
                position: "absolute",
                left: 0,
                right: 0,
                top: `${pct}%`,
                height: 1,
                background: "rgba(255,255,255,0.03)",
              }} />
            ))}
          </div>

          {/* Bars */}
          <div style={{ position: "absolute", left: 50, right: 0, top: 0, bottom: 40, display: "flex", alignItems: "flex-end", gap: 8, paddingRight: 20 }}>
            {drawdowns.map((d, i) => {
              const isCurrent = d.recovery === "?";
              const height = Math.abs(d.drawdown);
              const maxHeight = 100; // represents -100%
              
              return (
                <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "flex-end", height: "100%", position: "relative" }}>
                  {/* Bar */}
                  <div
                    style={{
                      width: "100%",
                      maxWidth: 60,
                      height: `${(height / maxHeight) * 100}%`,
                      background: isCurrent 
                        ? `linear-gradient(180deg, ${currentAsset.color} 0%, ${currentAsset.color}80 100%)`
                        : "linear-gradient(180deg, rgba(255,77,106,0.4) 0%, rgba(255,77,106,0.2) 100%)",
                      borderRadius: "4px 4px 0 0",
                      border: isCurrent ? `2px solid ${currentAsset.color}` : "1px solid rgba(255,77,106,0.3)",
                      position: "relative",
                      transition: "all 0.3s ease",
                      cursor: "pointer",
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = "scaleY(1.05)";
                      e.currentTarget.style.filter = "brightness(1.2)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = "scaleY(1)";
                      e.currentTarget.style.filter = "brightness(1)";
                    }}
                  >
                    {/* Percentage label on bar */}
                    <div style={{
                      position: "absolute",
                      top: -20,
                      left: "50%",
                      transform: "translateX(-50%)",
                      fontSize: 9,
                      fontWeight: 600,
                      color: isCurrent ? currentAsset.color : "#FF4D6A",
                      fontFamily: "'JetBrains Mono', monospace",
                      whiteSpace: "nowrap",
                    }}>
                      {d.drawdown.toFixed(1)}%
                    </div>
                    
                    {/* Current indicator */}
                    {isCurrent && (
                      <div style={{
                        position: "absolute",
                        top: -40,
                        left: "50%",
                        transform: "translateX(-50%)",
                        fontSize: 16,
                      }}>
                        ⚡
                      </div>
                    )}
                  </div>

                  {/* X-axis label */}
                  <div style={{
                    marginTop: 8,
                    fontSize: 8,
                    color: isCurrent ? currentAsset.color : "rgba(255,255,255,0.4)",
                    textAlign: "center",
                    fontWeight: isCurrent ? 600 : 400,
                    lineHeight: 1.2,
                    maxWidth: 60,
                  }}>
                    {d.date.split(" ").slice(0, 2).join(" ")}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Legend */}
        <div style={{ display: "flex", gap: 20, justifyContent: "center", marginTop: 16, paddingTop: 16, borderTop: "1px solid rgba(255,255,255,0.06)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <div style={{ width: 12, height: 12, borderRadius: 2, background: "linear-gradient(180deg, rgba(255,77,106,0.4) 0%, rgba(255,77,106,0.2) 100%)", border: "1px solid rgba(255,77,106,0.3)" }} />
            <span style={{ fontSize: 10, color: "rgba(255,255,255,0.5)" }}>Historical Drawdowns</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <div style={{ width: 12, height: 12, borderRadius: 2, background: `linear-gradient(180deg, ${currentAsset.color} 0%, ${currentAsset.color}80 100%)`, border: `2px solid ${currentAsset.color}` }} />
            <span style={{ fontSize: 10, color: "rgba(255,255,255,0.5)" }}>Current Dip ⚡</span>
          </div>
        </div>
      </div>

      {/* Historical comparison */}
      <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: 20 }}>
        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", textTransform: "uppercase", letterSpacing: 2, marginBottom: 20 }}>
          🔄 Historical Cycle Drawdowns
        </div>

        {drawdowns.map((d, i) => {
          const isCurrent = d.recovery === "?";
          const maxDrawdown = Math.max(...drawdowns.map(x => Math.abs(x.drawdown)));
          
          return (
            <div key={i} style={{
              marginBottom: 16, padding: "16px 20px", borderRadius: 10,
              background: isCurrent ? "rgba(255,77,106,0.06)" : "rgba(255,255,255,0.02)",
              border: isCurrent ? "2px solid rgba(255,77,106,0.2)" : "1px solid rgba(255,255,255,0.04)",
              transition: "all 0.2s ease",
            }}
            onMouseEnter={(e) => { if (!isCurrent) e.currentTarget.style.background = "rgba(255,255,255,0.04)"; }}
            onMouseLeave={(e) => { if (!isCurrent) e.currentTarget.style.background = "rgba(255,255,255,0.02)"; }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontSize: 13, fontWeight: 600, color: "#fff" }}>{d.event}</span>
                    {isCurrent && (
                      <span style={{ fontSize: 9, color: "#FF4D6A", background: "rgba(255,77,106,0.15)", padding: "2px 8px", borderRadius: 4, fontWeight: 600 }}>
                        CURRENT
                      </span>
                    )}
                  </div>
                  <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>
                    {d.date} · {d.cycle} cycle
                  </div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 20, fontWeight: 700, color: "#FF4D6A", fontFamily: "'JetBrains Mono', monospace" }}>
                    {d.drawdown.toFixed(1)}%
                  </div>
                  <div style={{ fontSize: 9, color: "rgba(255,255,255,0.3)" }}>{d.duration}</div>
                </div>
              </div>

              {/* Visual bar */}
              <div style={{ height: 8, background: "rgba(255,255,255,0.04)", borderRadius: 4, overflow: "hidden", marginBottom: 10 }}>
                <div style={{
                  width: `${(Math.abs(d.drawdown) / maxDrawdown) * 100}%`,
                  height: "100%",
                  background: isCurrent ? "#FF4D6A" : "rgba(255,77,106,0.5)",
                  borderRadius: 4,
                  transition: "width 1s ease",
                }} />
              </div>

              {/* Stats */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                <div>
                  <div style={{ fontSize: 9, color: "rgba(255,255,255,0.25)", textTransform: "uppercase", letterSpacing: 1 }}>Peak</div>
                  <div style={{ fontSize: 12, color: "rgba(255,255,255,0.7)", fontFamily: "'JetBrains Mono', monospace" }}>
                    ${d.peak.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: 9, color: "rgba(255,255,255,0.25)", textTransform: "uppercase", letterSpacing: 1 }}>Bottom</div>
                  <div style={{ fontSize: 12, color: "rgba(255,255,255,0.7)", fontFamily: "'JetBrains Mono', monospace" }}>
                    ${d.bottom.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: 9, color: "rgba(255,255,255,0.25)", textTransform: "uppercase", letterSpacing: 1 }}>Recovery</div>
                  <div style={{ fontSize: 12, color: isCurrent ? "#FF4D6A" : "#00E39E", fontFamily: "'JetBrains Mono', monospace" }}>
                    {d.recovery}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Insight box */}
      <div style={{
        marginTop: 20, background: "rgba(0,227,158,0.06)", border: "1px solid rgba(0,227,158,0.15)",
        borderRadius: 12, padding: 20,
      }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: "#00E39E", marginBottom: 8 }}>💡 Perspective</div>
        <div style={{ fontSize: 12, color: "rgba(255,255,255,0.7)", lineHeight: 1.6 }}>
          The current {currentAsset.name} drawdown of <strong>{currentDip.drawdown.toFixed(1)}%</strong> is {
            Math.abs(currentDip.drawdown) < 30 ? "relatively mild" :
            Math.abs(currentDip.drawdown) < 50 ? "moderate" :
            Math.abs(currentDip.drawdown) < 70 ? "significant" : "severe"
          } compared to historical cycle corrections. {
            selectedAsset === "bitcoin" && "BTC has weathered drawdowns as large as -84.8% (Mt. Gox) and recovered."
          }{
            selectedAsset === "ethereum" && "ETH has seen corrections up to -72% (DAO Hack) and bounced back stronger."
          }{
            selectedAsset === "solana" && "SOL survived a -96.9% crash during FTX and recovered to new highs."
          }
        </div>
      </div>
    </div>
  );
}

// --- WHAT IF CALCULATOR ---
function WhatIfCalculator() {
  const [btcIncrease, setBtcIncrease] = useState("");
  const [ethIncrease, setEthIncrease] = useState("");
  const [solIncrease, setSolIncrease] = useState("");
  const [reason, setReason] = useState("");
  const [years, setYears] = useState("3");
  const [showResults, setShowResults] = useState(false);
  const [giphyUrl, setGiphyUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [projectionLog, setProjectionLog] = useState([]);
  const [storageLoading, setStorageLoading] = useState(true);

  // Load shared projection log on mount
  useEffect(() => {
    loadProjectionLog();
  }, []);

  const loadProjectionLog = async () => {
    try {
      const result = await window.storage.get('allium-projection-log', true);
      if (result && result.value) {
        const logs = JSON.parse(result.value);
        setProjectionLog(logs);
        console.log("Loaded", logs.length, "projections from shared storage");
      }
    } catch (err) {
      console.log("No existing log found or error loading:", err);
    } finally {
      setStorageLoading(false);
    }
  };

  const saveProjectionLog = async (newLog) => {
    try {
      await window.storage.set('allium-projection-log', JSON.stringify(newLog), true);
      console.log("Saved projection log to shared storage");
    } catch (err) {
      console.error("Error saving to shared storage:", err);
    }
  };

  const calculateProjections = async () => {
    if (!btcIncrease && !ethIncrease && !solIncrease) return;
    if (!reason.trim()) {
      alert("Don't forget to tell us WHY this will happen! 🚀");
      return;
    }

    setLoading(true);
    setShowResults(false);

    // Create log entry
    const logEntry = {
      timestamp: new Date().toLocaleString(),
      years,
      btc: btcIncrease || "N/A",
      eth: ethIncrease || "N/A",
      sol: solIncrease || "N/A",
      reason,
    };

    // Add to log (keep last 20 for company-wide view)
    const updatedLog = [logEntry, ...projectionLog].slice(0, 20);
    setProjectionLog(updatedLog);
    
    // Save to shared storage so all users see it
    await saveProjectionLog(updatedLog);

    // Console log for debugging
    console.log("=== WHAT IF PROJECTION LOG ===");
    console.log("Timestamp:", logEntry.timestamp);
    console.log("Years:", years);
    console.log("BTC Increase:", btcIncrease || "N/A");
    console.log("ETH Increase:", ethIncrease || "N/A");
    console.log("SOL Increase:", solIncrease || "N/A");
    console.log("Reason:", reason);
    console.log("==============================");

    // Create animated celebration visual (no external resources needed)
    const celebrations = [
      { emoji: "💰", text: "MONEY PRINTER GO BRRRR", color: "#00E39E" },
      { emoji: "🚀", text: "TO THE MOON!", color: "#F7931A" },
      { emoji: "📈", text: "STONKS ONLY GO UP", color: "#627EEA" },
    ];
    
    const randomCelebration = celebrations[Math.floor(Math.random() * celebrations.length)];
    console.log("Selected celebration:", randomCelebration.text);
    setGiphyUrl(JSON.stringify(randomCelebration)); // Store as string to trigger display

    // Small delay to show the loading state
    await new Promise(resolve => setTimeout(resolve, 800));
    
    setLoading(false);
    setShowResults(true);
  };

  const currentPrices = {
    btc: PRICE_DATA.bitcoin.price,
    eth: PRICE_DATA.ethereum.price,
    sol: PRICE_DATA.solana.price,
  };

  const projections = {
    btc: btcIncrease ? currentPrices.btc * (1 + parseFloat(btcIncrease) / 100) : null,
    eth: ethIncrease ? currentPrices.eth * (1 + parseFloat(ethIncrease) / 100) : null,
    sol: solIncrease ? currentPrices.sol * (1 + parseFloat(solIncrease) / 100) : null,
  };

  const assets = [
    { id: "btc", name: "BTC", color: "#F7931A", current: currentPrices.btc, projected: projections.btc, increase: btcIncrease },
    { id: "eth", name: "ETH", color: "#627EEA", current: currentPrices.eth, projected: projections.eth, increase: ethIncrease },
    { id: "sol", name: "SOL", color: "#00FFA3", current: currentPrices.sol, projected: projections.sol, increase: solIncrease },
  ];

  return (
    <div>
      {/* Loading state */}
      {storageLoading && (
        <div style={{
          background: "rgba(0,227,158,0.06)", border: "1px solid rgba(0,227,158,0.15)",
          borderRadius: 12, padding: 16, marginBottom: 24, textAlign: "center",
        }}>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.6)" }}>
            🔄 Loading company projections...
          </div>
        </div>
      )}

      {/* Input Form */}
      <div style={{
        background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)",
        borderRadius: 12, padding: 24, marginBottom: 24,
      }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: "#fff", marginBottom: 6 }}>
          🔮 Crystal Ball Mode
        </div>
        <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 20 }}>
          Enter your wildly optimistic (or realistic?) price projections
        </div>

        {/* Years selector */}
        <div style={{ marginBottom: 20 }}>
          <label style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", display: "block", marginBottom: 8 }}>
            Time Horizon
          </label>
          <div style={{ display: "flex", gap: 8 }}>
            {["2", "3", "4", "5"].map((y) => (
              <button key={y} onClick={() => setYears(y)} style={{
                flex: 1, padding: "10px", borderRadius: 8, cursor: "pointer", transition: "all 0.2s ease",
                background: years === y ? "rgba(0,227,158,0.15)" : "rgba(255,255,255,0.04)",
                border: years === y ? "1px solid rgba(0,227,158,0.3)" : "1px solid rgba(255,255,255,0.06)",
                color: years === y ? "#00E39E" : "rgba(255,255,255,0.5)",
                fontSize: 13, fontWeight: years === y ? 600 : 400,
              }}>
                {y} years
              </button>
            ))}
          </div>
        </div>

        {/* Price increase inputs */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginBottom: 20 }}>
          {[
            { label: "BTC", value: btcIncrease, setter: setBtcIncrease, color: "#F7931A" },
            { label: "ETH", value: ethIncrease, setter: setEthIncrease, color: "#627EEA" },
            { label: "SOL", value: solIncrease, setter: setSolIncrease, color: "#00FFA3" },
          ].map((asset) => (
            <div key={asset.label}>
              <label style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", display: "block", marginBottom: 6 }}>
                {asset.label} % Increase
              </label>
              <div style={{ position: "relative" }}>
                <input
                  type="number"
                  value={asset.value}
                  onChange={(e) => asset.setter(e.target.value)}
                  placeholder="0"
                  style={{
                    width: "100%", padding: "12px 32px 12px 12px", background: "rgba(255,255,255,0.04)",
                    border: `1px solid ${asset.value ? asset.color + "40" : "rgba(255,255,255,0.1)"}`,
                    borderRadius: 8, color: "#fff", fontSize: 14, fontFamily: "'JetBrains Mono', monospace",
                    outline: "none", transition: "all 0.2s ease",
                  }}
                />
                <span style={{
                  position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)",
                  fontSize: 13, color: "rgba(255,255,255,0.3)", fontFamily: "'JetBrains Mono', monospace",
                }}>
                  %
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Reason input */}
        <div style={{ marginBottom: 20 }}>
          <label style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", display: "block", marginBottom: 6 }}>
            Why Will This Happen? 🤔
          </label>
          <input
            type="text"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="e.g., Trump re-elected, ETF approval, hyperbitcoinization..."
            style={{
              width: "100%", padding: "12px 16px", background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#fff",
              fontSize: 13, outline: "none",
            }}
          />
        </div>

        {/* Calculate button */}
        <button onClick={calculateProjections} disabled={loading} style={{
          width: "100%", padding: "14px", borderRadius: 10, border: "none", cursor: "pointer",
          background: "linear-gradient(135deg, #00E39E, #00B87C)",
          color: "#0A0B0E", fontSize: 14, fontWeight: 700, transition: "all 0.2s ease",
          opacity: loading ? 0.6 : 1,
        }}
        onMouseEnter={(e) => { if (!loading) e.currentTarget.style.transform = "translateY(-2px)"; }}
        onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; }}
        >
          {loading ? "🔮 Consulting the Oracle..." : "🚀 Show Me the Money!"}
        </button>
      </div>

      {/* Results */}
      {showResults && (
        <div>
          {/* Reason banner */}
          <div style={{
            background: "rgba(0,227,158,0.08)", border: "1px solid rgba(0,227,158,0.2)",
            borderRadius: 12, padding: 20, marginBottom: 24, textAlign: "center",
          }}>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: 2, marginBottom: 8 }}>
              The Catalyst
            </div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "#00E39E", marginBottom: 4 }}>
              "{reason}"
            </div>
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)" }}>
              {years}-year projection · Because obviously this will happen 📈
            </div>
          </div>

          {/* Celebration Animation - No external resources! */}
          <div style={{
            marginBottom: 24, borderRadius: 12, overflow: "hidden",
            border: "3px solid rgba(0,227,158,0.4)", background: "linear-gradient(135deg, #0A0B0E 0%, #1a1b1f 100%)",
            boxShadow: "0 8px 32px rgba(0,227,158,0.2)",
            minHeight: 300,
            position: "relative",
          }}>
            <style>{`
              @keyframes float {
                0%, 100% { transform: translateY(0px) rotate(0deg); }
                50% { transform: translateY(-20px) rotate(5deg); }
              }
              @keyframes pulse-glow {
                0%, 100% { box-shadow: 0 0 20px currentColor, 0 0 40px currentColor; }
                50% { box-shadow: 0 0 40px currentColor, 0 0 80px currentColor; }
              }
              @keyframes sparkle {
                0%, 100% { opacity: 0; transform: scale(0) rotate(0deg); }
                50% { opacity: 1; transform: scale(1) rotate(180deg); }
              }
              @keyframes slide-up {
                from { transform: translateY(20px); opacity: 0; }
                to { transform: translateY(0); opacity: 1; }
              }
            `}</style>
            
            {giphyUrl ? (() => {
              const celebration = JSON.parse(giphyUrl);
              return (
                <div style={{
                  padding: 60, textAlign: "center", display: "flex", flexDirection: "column",
                  alignItems: "center", justifyContent: "center", minHeight: 300,
                  position: "relative",
                }}>
                  {/* Sparkles background */}
                  {[...Array(8)].map((_, i) => (
                    <div key={i} style={{
                      position: "absolute",
                      top: `${20 + (i * 10)}%`,
                      left: `${10 + (i * 11)}%`,
                      fontSize: 20,
                      animation: `sparkle ${1.5 + (i * 0.2)}s ease-in-out infinite`,
                      animationDelay: `${i * 0.2}s`,
                    }}>
                      ✨
                    </div>
                  ))}
                  
                  {/* Main emoji */}
                  <div style={{ 
                    fontSize: 120, 
                    marginBottom: 20,
                    animation: "float 2s ease-in-out infinite",
                    filter: "drop-shadow(0 10px 30px rgba(0,227,158,0.3))",
                  }}>
                    {celebration.emoji}
                  </div>
                  
                  {/* Text */}
                  <div style={{ 
                    fontSize: 28, 
                    color: celebration.color, 
                    fontWeight: 900, 
                    marginBottom: 12,
                    textShadow: `0 0 20px ${celebration.color}, 0 0 40px ${celebration.color}`,
                    animation: "slide-up 0.5s ease-out",
                    letterSpacing: 2,
                  }}>
                    {celebration.text}
                  </div>
                  
                  {/* Sub text */}
                  <div style={{ 
                    fontSize: 14, 
                    color: "rgba(255,255,255,0.6)", 
                    fontWeight: 600,
                    animation: "slide-up 0.7s ease-out",
                  }}>
                    Your projection has been saved! 🎉
                  </div>
                </div>
              );
            })() : (
              <div style={{
                padding: 40, textAlign: "center", display: "flex", flexDirection: "column",
                alignItems: "center", justifyContent: "center", minHeight: 300,
              }}>
                <div style={{ fontSize: 64, marginBottom: 12 }}>🚀</div>
                <div style={{ fontSize: 14, color: "#00E39E", fontWeight: 600, marginBottom: 4 }}>
                  To the moon!
                </div>
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>
                  (Loading celebration...)
                </div>
              </div>
            )}
          </div>

          {/* Price projections */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginBottom: 24 }}>
            {assets.filter(a => a.projected).map((asset) => {
              const gain = asset.projected - asset.current;
              const mult = asset.projected / asset.current;

              return (
                <div key={asset.id} style={{
                  background: `${asset.color}08`, border: `1px solid ${asset.color}20`,
                  borderRadius: 12, padding: 20,
                }}>
                  <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginBottom: 4 }}>
                    {asset.name}
                  </div>
                  <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", marginBottom: 12 }}>
                    Current: ${asset.current.toLocaleString()}
                  </div>
                  
                  <div style={{ fontSize: 24, fontWeight: 700, color: asset.color, fontFamily: "'JetBrains Mono', monospace", marginBottom: 8 }}>
                    ${asset.projected.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </div>
                  
                  <div style={{ fontSize: 11, color: "#00E39E", marginBottom: 8 }}>
                    +{asset.increase}% ({mult.toFixed(1)}x)
                  </div>
                  
                  <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)" }}>
                    Gain: ${gain.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Portfolio calculator */}
          <div style={{
            background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)",
            borderRadius: 12, padding: 20,
          }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: "#fff", marginBottom: 16 }}>
              💰 If You Invested $10,000 Today...
            </div>
            
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
              {assets.filter(a => a.projected).map((asset) => {
                const futureValue = 10000 * (asset.projected / asset.current);
                const profit = futureValue - 10000;

                return (
                  <div key={asset.id} style={{
                    background: "rgba(255,255,255,0.02)", borderRadius: 8, padding: 16,
                    border: "1px solid rgba(255,255,255,0.04)",
                  }}>
                    <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginBottom: 8 }}>
                      $10k in {asset.name}
                    </div>
                    <div style={{ fontSize: 18, fontWeight: 700, color: asset.color, fontFamily: "'JetBrains Mono', monospace", marginBottom: 4 }}>
                      ${futureValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </div>
                    <div style={{ fontSize: 10, color: "#00E39E" }}>
                      Profit: ${profit.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Disclaimer */}
          <div style={{
            marginTop: 20, padding: 16, background: "rgba(255,255,255,0.02)",
            borderRadius: 8, border: "1px solid rgba(255,255,255,0.04)",
          }}>
            <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", lineHeight: 1.6, textAlign: "center" }}>
              ⚠️ This is for entertainment purposes only. Past performance doesn't guarantee future results.
              Markets can go down too (see the Market Freakout tab for proof). DYOR. NFA. WAGMI? 🚀
            </div>
          </div>
        </div>
      )}

      {/* Projection Log */}
      {projectionLog.length > 0 && (
        <div style={{
          marginTop: 32, background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)",
          borderRadius: 12, padding: 20,
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: "#fff" }}>📊 Company-Wide Projections Log</div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", marginTop: 2 }}>
                Last {projectionLog.length} projection{projectionLog.length > 1 ? 's' : ''} · Shared across your team
              </div>
            </div>
            <button onClick={async () => { 
              setProjectionLog([]);
              await window.storage.delete('allium-projection-log', true);
              console.log("Cleared shared projection log");
            }} style={{
              padding: "6px 12px", borderRadius: 6, border: "1px solid rgba(255,255,255,0.1)",
              background: "rgba(255,255,255,0.04)", color: "rgba(255,255,255,0.5)",
              fontSize: 10, cursor: "pointer", transition: "all 0.2s ease",
            }}
            onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(255,77,106,0.1)"; e.currentTarget.style.color = "#FF4D6A"; }}
            onMouseLeave={(e) => { e.currentTarget.style.background = "rgba(255,255,255,0.04)"; e.currentTarget.style.color = "rgba(255,255,255,0.5)"; }}
            >
              Clear Log
            </button>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {projectionLog.map((log, i) => (
              <div key={i} style={{
                padding: "12px 16px", background: i === 0 ? "rgba(0,227,158,0.04)" : "rgba(255,255,255,0.02)",
                border: i === 0 ? "1px solid rgba(0,227,158,0.15)" : "1px solid rgba(255,255,255,0.04)",
                borderRadius: 8, transition: "all 0.2s ease",
              }}
              onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(255,255,255,0.06)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.background = i === 0 ? "rgba(0,227,158,0.04)" : "rgba(255,255,255,0.02)"; }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: "#fff", marginBottom: 4 }}>
                      "{log.reason}"
                    </div>
                    <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)" }}>
                      {log.timestamp} · {log.years}-year projection
                    </div>
                  </div>
                  {i === 0 && (
                    <span style={{ fontSize: 9, color: "#00E39E", background: "rgba(0,227,158,0.15)", padding: "2px 8px", borderRadius: 4, fontWeight: 600 }}>
                      LATEST
                    </span>
                  )}
                </div>
                <div style={{ display: "flex", gap: 16 }}>
                  {log.btc !== "N/A" && (
                    <div style={{ fontSize: 11, color: "#F7931A", fontFamily: "'JetBrains Mono', monospace" }}>
                      BTC: +{log.btc}%
                    </div>
                  )}
                  {log.eth !== "N/A" && (
                    <div style={{ fontSize: 11, color: "#627EEA", fontFamily: "'JetBrains Mono', monospace" }}>
                      ETH: +{log.eth}%
                    </div>
                  )}
                  {log.sol !== "N/A" && (
                    <div style={{ fontSize: 11, color: "#00FFA3", fontFamily: "'JetBrains Mono', monospace" }}>
                      SOL: +{log.sol}%
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// === WALLET LOOKUP (uses Claude API → Allium MCP) ===
function WalletLookup() {
  const [address, setAddress] = useState("");
  const [chain, setChain] = useState("ethereum");
  const [transactions, setTransactions] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchWallet = useCallback(async (addr, ch) => {
    if (!addr || addr.length < 10) return;
    setLoading(true);
    setError(null);
    setTransactions(null);

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{
            role: "user",
            content: `Look up the latest 10 transactions for wallet address ${addr} on ${ch}. Return the results as a JSON array where each item has: hash, block_timestamp, from_address, to_address, labels, and for each asset_transfer: transfer_type, asset_symbol, asset_name, amount_str. Only return valid JSON, no other text.`
          }],
          mcp_servers: [{
            type: "url",
            url: "https://mcp-oauth.allium.so",
            name: "allium"
          }]
        }),
      });

      const data = await response.json();
      const toolResults = data.content?.filter(c => c.type === "mcp_tool_result").map(c => c.content?.[0]?.text).filter(Boolean);
      const textResults = data.content?.filter(c => c.type === "text").map(c => c.text).join("\n");

      // Try to parse structured data from tool results first, then text
      let parsed = null;
      for (const result of [...(toolResults || []), textResults]) {
        if (!result) continue;
        try {
          const clean = result.replace(/```json\n?|```/g, "").trim();
          parsed = JSON.parse(clean);
          break;
        } catch(e) { /* continue */ }
      }

      if (parsed?.items) {
        setTransactions(parsed.items);
      } else if (Array.isArray(parsed)) {
        setTransactions(parsed);
      } else {
        // Fall back to showing raw response
        setTransactions(textResults || "No data returned");
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleLookup = () => fetchWallet(address, chain);

  // Demo data from Vitalik's wallet (pre-loaded from our earlier query)
  const DEMO_TXS = [
    { hash: "0xba2b8b31...3be9eb", block_timestamp: "2026-02-05T16:31:47", from_address: "0x74c10e4bbe847d68ce02a9abb4bab8dbedfd4675", to_address: "0xd714a9c3836edd56198576ebfbc8d23ea3cb405e", labels: ["transfer"], asset_transfers: [{ transfer_type: "received", asset: { type: "evm_erc20", symbol: "CTO", name: "Ethereum CTO", decimals: 9 }, amount: { amount_str: "1000000", amount: 1000000 } }] },
    { hash: "0x5b0d81ba...1b898", block_timestamp: "2026-02-05T13:43:47", from_address: "0xf8fc9a91349ebd2033d53f2b97245102f00aba96", to_address: "0xd8da6bf26964af9d7eed9e03e53415d37aa96045", labels: ["transfer"], asset_transfers: [{ transfer_type: "received", asset: { type: "native", symbol: "ETH", name: "Ether", decimals: 18 }, amount: { amount_str: "0.000505", amount: 0.000505 } }] },
    { hash: "0x92434a46...1b383d", block_timestamp: "2026-02-05T09:43:23", from_address: "0xb063b093f7cd53165b4e7d32ff85803ae0572ea9", to_address: "0xd8da6bf26964af9d7eed9e03e53415d37aa96045", labels: ["transfer"], asset_transfers: [{ transfer_type: "received", asset: { type: "native", symbol: "ETH", name: "Ether", decimals: 18 }, amount: { amount_str: "0.000000001", amount: 1e-9 } }] },
    { hash: "0x67852cbf...c4bbb0", block_timestamp: "2026-02-05T09:42:47", from_address: "0xb06896fbc28370a70b86bda84db0931f09f99ea9", to_address: "0x761d38e5ddf6ccf6cf7c55759d5210750b5d60f3", labels: ["transfer"], asset_transfers: [{ transfer_type: "received", asset: { type: "evm_erc20", symbol: "ELON", name: "Dogelon", decimals: 18 }, amount: { amount_str: "0.0000666", amount: 0.0000666 } }] },
    { hash: "0xd5efd7dc...7d69c", block_timestamp: "2026-02-05T09:40:35", from_address: "0xf250259b35bda8c3e1b3f0b46ce4cd9b503c865b", to_address: "0x761d38e5ddf6ccf6cf7c55759d5210750b5d60f3", labels: ["transfer"], asset_transfers: [{ transfer_type: "received", asset: { type: "evm_erc20", symbol: "ELON", name: "Dogelon", decimals: 18 }, amount: { amount_str: "0.0000666", amount: 0.0000666 } }] },
  ];

  const displayTxs = transactions || DEMO_TXS;
  const isDemo = !transactions;

  return (
    <div>
      {/* Search bar */}
      <div style={{
        background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 12,
        padding: 20, marginBottom: 20,
      }}>
        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", textTransform: "uppercase", letterSpacing: 2, marginBottom: 12 }}>
          🔍 Wallet Lookup
        </div>
        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          {["ethereum", "solana"].map((c) => (
            <button key={c} onClick={() => setChain(c)} style={{
              padding: "6px 14px", borderRadius: 6, fontSize: 11, cursor: "pointer", transition: "all 0.15s ease",
              background: chain === c ? (c === "ethereum" ? "rgba(98,126,234,0.2)" : "rgba(0,255,163,0.2)") : "rgba(255,255,255,0.04)",
              border: chain === c ? `1px solid ${c === "ethereum" ? "#627EEA" : "#00FFA3"}40` : "1px solid rgba(255,255,255,0.06)",
              color: chain === c ? "#fff" : "rgba(255,255,255,0.4)",
            }}>
              {c === "ethereum" ? "Ethereum" : "Solana"}
            </button>
          ))}
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <input
            type="text"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="Paste any wallet address..."
            onKeyDown={(e) => e.key === "Enter" && handleLookup()}
            style={{
              flex: 1, padding: "12px 16px", background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#fff",
              fontSize: 13, fontFamily: "'JetBrains Mono', monospace", outline: "none",
            }}
          />
          <button onClick={handleLookup} disabled={loading || address.length < 10} style={{
            padding: "12px 24px", borderRadius: 8, border: "none", cursor: address.length >= 10 ? "pointer" : "default",
            background: address.length >= 10 ? "#00E39E" : "rgba(255,255,255,0.06)",
            color: address.length >= 10 ? "#0A0B0E" : "rgba(255,255,255,0.3)",
            fontWeight: 600, fontSize: 13, transition: "all 0.2s ease",
          }}>
            {loading ? "..." : "Lookup"}
          </button>
        </div>

        {/* Example wallets */}
        <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
          <span style={{ fontSize: 10, color: "rgba(255,255,255,0.2)", alignSelf: "center" }}>Try:</span>
          {EXAMPLE_WALLETS.map((w) => (
            <button key={w.address} onClick={() => { setAddress(w.address); setChain(w.chain); }} style={{
              padding: "4px 10px", borderRadius: 4, border: "1px solid rgba(255,255,255,0.06)",
              background: "rgba(255,255,255,0.02)", color: "rgba(255,255,255,0.5)",
              fontSize: 10, cursor: "pointer", transition: "all 0.15s ease",
            }}
            onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(255,255,255,0.06)"; e.currentTarget.style.color = "#fff"; }}
            onMouseLeave={(e) => { e.currentTarget.style.background = "rgba(255,255,255,0.02)"; e.currentTarget.style.color = "rgba(255,255,255,0.5)"; }}
            >
              {w.label}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div style={{ background: "rgba(255,77,106,0.06)", border: "1px solid rgba(255,77,106,0.15)", borderRadius: 10, padding: "14px 20px", marginBottom: 16, fontSize: 13, color: "#FF4D6A" }}>
          {error}
        </div>
      )}

      {loading && <Spinner />}

      {/* Transaction feed */}
      {!loading && (
        <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, overflow: "hidden" }}>
          <div style={{ padding: "16px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <span style={{ fontSize: 12, fontWeight: 600, color: "#fff" }}>Recent Transactions</span>
              {isDemo && (
                <span style={{ fontSize: 10, color: "rgba(255,255,255,0.25)", marginLeft: 8, padding: "2px 8px", background: "rgba(255,255,255,0.04)", borderRadius: 4 }}>
                  Demo: vitalik.eth
                </span>
              )}
            </div>
            {!isDemo && <span style={{ fontSize: 10, color: "#00E39E" }}>{shortenAddr(address)}</span>}
          </div>

          {typeof displayTxs === "string" ? (
            <pre style={{ padding: 20, fontSize: 12, color: "rgba(255,255,255,0.6)", fontFamily: "'JetBrains Mono', monospace", whiteSpace: "pre-wrap", maxHeight: 300, overflow: "auto" }}>
              {displayTxs}
            </pre>
          ) : Array.isArray(displayTxs) ? (
            displayTxs.map((tx, i) => <TxRow key={tx.hash || i} tx={tx} index={i} />)
          ) : null}
        </div>
      )}
    </div>
  );
}

// ============ MAIN APP ============
function function AlliumIntelApp() {
  const [tab, setTab] = useState("wallet");

  return (
    <div style={{ minHeight: "100vh", background: "#0A0B0E", color: "#fff", fontFamily: "'Inter','Helvetica Neue',sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Inter:wght@300;400;500;600;700&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}::selection{background:#00E39E40;color:#fff}
        ::-webkit-scrollbar{width:6px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:rgba(255,255,255,0.1);border-radius:3px}
      `}</style>

      <div style={{ position: "fixed", inset: 0, backgroundImage: "radial-gradient(circle at 15% 25%, rgba(0,227,158,0.04) 0%, transparent 50%), radial-gradient(circle at 85% 75%, rgba(98,126,234,0.04) 0%, transparent 50%)", pointerEvents: "none" }} />

      <div style={{ position: "relative", zIndex: 1, maxWidth: 1000, margin: "0 auto", padding: "36px 24px" }}>

        {/* HEADER */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 32, flexWrap: "wrap", gap: 16 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
              <div style={{ width: 30, height: 30, borderRadius: 7, background: "linear-gradient(135deg, #00E39E, #627EEA)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, fontWeight: 700 }}>A</div>
              <h1 style={{ fontSize: 20, fontWeight: 600, letterSpacing: "-0.02em", color: "#fff" }}>Allium Intelligence</h1>
              <span style={{ fontSize: 9, color: "rgba(255,255,255,0.3)", padding: "2px 8px", background: "rgba(255,255,255,0.04)", borderRadius: 4, textTransform: "uppercase", letterSpacing: 1.5 }}>Sales Tool</span>
            </div>
            <p style={{ fontSize: 12, color: "rgba(255,255,255,0.3)" }}>
              Real-time wallet intelligence & market data · Powered by Allium MCP
            </p>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "4px 10px", background: "rgba(0,227,158,0.08)", border: "1px solid rgba(0,227,158,0.15)", borderRadius: 20 }}>
              <div style={{ width: 5, height: 5, borderRadius: "50%", background: "#00E39E" }} />
              <span style={{ fontSize: 9, color: "#00E39E", fontWeight: 600, letterSpacing: 1 }}>REAL DATA</span>
            </div>
            <LiveDot />
          </div>
        </div>

        {/* TAB NAV */}
        <div style={{ display: "flex", gap: 8, marginBottom: 28, flexWrap: "wrap" }}>
          <TabButton label="🔍 Wallet Lookup" active={tab === "wallet"} onClick={() => setTab("wallet")} color="#00E39E" />
          <TabButton label="📊 Market Overview" active={tab === "market"} onClick={() => setTab("market")} color="#627EEA" />
          <TabButton label="🔥 Market Freakout" active={tab === "freakout"} onClick={() => setTab("freakout")} color="#FF4D6A" />
          <TabButton label="🔮 What If" active={tab === "whatif"} onClick={() => setTab("whatif")} color="#00E39E" />
        </div>

        {/* CONTENT */}
        {tab === "wallet" && <WalletLookup />}

        {tab === "market" && (
          <div>
            <MarketMini />
            <div style={{ marginTop: 20, background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: 20 }}>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", textTransform: "uppercase", letterSpacing: 2, marginBottom: 16 }}>
                7-Day Stablecoin Flows
              </div>
              {["ethereum", "solana"].map((ch) => {
                const d = STABLECOIN_DATA[ch];
                const max = Math.max(d.usdc, d.usdt, Math.max(d.dai, 0.01));
                const bars = [
                  { label: "USDC", value: d.usdc, color: "#2775CA" },
                  { label: "USDT", value: d.usdt, color: "#26A17B" },
                  { label: "DAI", value: d.dai, color: "#F5AC37" },
                ];
                return (
                  <div key={ch} style={{ marginBottom: 20 }}>
                    <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", marginBottom: 8, textTransform: "capitalize" }}>{ch}</div>
                    {bars.map((b) => (
                      <div key={b.label} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                        <span style={{ width: 36, fontSize: 10, color: "rgba(255,255,255,0.4)", fontFamily: "'JetBrains Mono', monospace" }}>{b.label}</span>
                        <div style={{ flex: 1, height: 16, background: "rgba(255,255,255,0.03)", borderRadius: 3, overflow: "hidden" }}>
                          <div style={{ width: `${Math.max((b.value / max) * 100, 0.5)}%`, height: "100%", background: b.color, borderRadius: 3, transition: "width 1s ease" }} />
                        </div>
                        <span style={{ width: 55, fontSize: 11, color: "rgba(255,255,255,0.6)", fontFamily: "'JetBrains Mono', monospace", textAlign: "right" }}>
                          ${b.value >= 1 ? b.value.toFixed(0) + "B" : "<1B"}
                        </span>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {tab === "freakout" && <MarketFreakout />}

        {tab === "whatif" && <WhatIfCalculator />}

        {/* FOOTER */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 24, marginTop: 24, borderTop: "1px solid rgba(255,255,255,0.04)", flexWrap: "wrap", gap: 12 }}>
          <div style={{ fontSize: 10, color: "rgba(255,255,255,0.15)" }}>Allium Intelligence · Built with Allium × Claude · Feb 2026</div>
          <div style={{ fontSize: 10, color: "rgba(255,255,255,0.15)" }}>130+ chains · 1,000+ schemas · Real-time + historical</div>
        </div>
      </div>
    </div>
  );
}
