# 🚀 Allium Intelligence Dashboard - Next.js

Super easy to deploy! Next.js works perfectly with Vercel (no 404 errors!)

## ✨ Deploy to Vercel (EASIEST - 2 Minutes!)

### Method 1: GitHub → Vercel (Recommended)

1. **Create GitHub Repository:**
   - Go to https://github.com/new
   - Name it "allium-dashboard"
   - Make it Public or Private (your choice)
   - Click "Create repository"

2. **Upload Files:**
   - Download and extract the ZIP
   - Drag all files into your GitHub repo
   - Or use GitHub Desktop / command line

3. **Deploy to Vercel:**
   - Go to https://vercel.com/signup
   - Sign up with GitHub (FREE!)
   - Click "Add New Project"
   - Select your "allium-dashboard" repo
   - Click "Deploy"
   - **DONE!** 🎉

   Your site will be live at: `your-project.vercel.app`

### Method 2: Direct Upload to Vercel

1. Download and extract the ZIP
2. Go to https://vercel.com
3. Click "Add New" → "Project"  
4. Click "Import" and select your folder
5. Click "Deploy"
6. Done!

## 🎯 What's Included

✅ **Next.js 14** - Latest version, super fast
✅ **All Dashboard Features** - Wallet lookup, market data, projections
✅ **Animated Celebrations** - Working perfectly!
✅ **Shared Storage** - Company-wide projection log
✅ **Zero Config** - Just deploy and go

## 📁 Project Structure

```
allium-dashboard/
├── app/
│   ├── layout.js       # HTML structure
│   └── page.js         # Your full dashboard
├── package.json        # Dependencies
├── next.config.js      # Next.js config
└── .gitignore         # Git ignore file
```

## 🔧 Run Locally (Optional)

```bash
npm install
npm run dev
```

Open http://localhost:3000

## 🌐 Custom Domain

After deploying on Vercel:
1. Go to your project settings
2. Click "Domains"
3. Add your domain (like `crypto.yourcompany.com`)
4. Follow DNS instructions
5. SSL certificate automatically added!

## 💾 Storage

- Uses localStorage (browser storage)
- Each user sees their own data
- For TRUE shared storage across all users, you'd need a backend

## 🆘 Troubleshooting

**Build fails?**
- Check that all files uploaded correctly
- Make sure package.json is in root folder

**Page not loading?**
- Clear browser cache
- Try incognito mode
- Check Vercel deployment logs

**Still stuck?**
Just tell me the error and I'll help fix it!

## 🎨 Features

✅ 🔍 **Wallet Lookup** - Real Allium data
✅ 📊 **Market Overview** - ETH & SOL prices
✅ 🔥 **Market Freakout** - Historical crash comparisons
✅ 🔮 **What If Calculator** - Price projections with animations!
✅ 📝 **Company Log** - See everyone's predictions

## 📱 Shareable

After deploying, share your URL with:
- Your team
- Your friends
- Your investors
- Anyone!

No login required to view!

## 💡 Pro Tips

- Vercel auto-deploys when you push to GitHub
- Free SSL certificate included
- Built-in analytics available
- Can add password protection in settings

---

**Ready to go live?** Just upload to GitHub and deploy to Vercel! 🚀
